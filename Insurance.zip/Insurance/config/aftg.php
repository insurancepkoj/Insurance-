<?php

return [
	'username' => env('AFRICAS_TALKING_USERNAME', ''),
	'api_key' => env('AFFRICAS_TALKING_API_KEY', ''),
];
