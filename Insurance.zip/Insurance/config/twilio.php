<?php

return [
	'account_sid' => env('TWILIO_ACCOUNT_SID', ''),
	'auth_token' => env('TWILIO_AUTH_TOKEN', ''),
	'number' => env('TWILIO_NUMBER', ''),
];
