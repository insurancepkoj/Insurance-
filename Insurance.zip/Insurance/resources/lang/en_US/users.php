<?php

return [

    /*
    |--------------------------------------------------------------------------
    | User Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match text used 
    | with the User model on Insura.
    |
    */

    'messages'      => [
        'error'     => [
            'missing'   => 'No such user was found!'
        ]
    ],

];
