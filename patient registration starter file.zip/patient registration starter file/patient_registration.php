<?php 
   
   include '../components/connect.php';

   if (isset($_COOKIE['user_id'])) {
      $user_id = $_COOKIE['user_id'];
   }else{
      $user_id = '';
      
   }

   

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Patient Registration</title>

   <!-- box icon cdn link  -->
   <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
   <link rel="stylesheet" type="text/css" href="../css/admin_style.css?v=<?php echo "time"; ?>">

   <!-- Add CSS for intl-tel-input -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">

   <!-- Add JavaScript for intl-tel-input -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

   <!-- You can optionally add this to get better number formatting -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>

   

</head>
<body>
   
   
<!-- register section starts  -->


<!-- registe section ends -->




   <!-- custom js link  -->
   <script type="text/javascript" src="../js/admin_script.js"></script>

   <?php include '../components/alert.php'; ?>
   

   <script>
      var input = document.querySelector("#contact");
      var iti = intlTelInput(input, {
         initialCountry: "auto", // Auto-detect the country based on the user's IP
         geoIpLookup: function(callback) {
            fetch("https://ipinfo.io", { headers: { "Accept": "application/json" } })
               .then(response => response.json())
               .then(data => callback(data.country)); // Auto-detect country
         },
         utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js" // Optional, for formatting
      });

   // When the form is submitted, capture the number with the country code
   function getPhoneNumber() {
      const phoneNumber = iti.getNumber(); // This will return the number with the country code
      document.getElementById('contact').value = phoneNumber; // For debugging
      // You can submit this phone number along with the rest of the form data
      return true;
   }
</script>
   
         
  
</body>
</html>